//20191339 ChanHwiHwang
#include <iostream>

using namespace std;

int main() {
	double num1, num2;
	cout << "Enter two numbers to find average :";
	cin >> num1 >> num2;
	cout << "The average of them is " << (num1+num2)/2.0 << endl;
	return 0;
}
